-----------------------------------------------------------------
VB-CABLE (Audio Device Driver MME, DX, WDM)
-----------------------------------------------------------------

CONTENT:
   - INSTALLATION 	    
   - LICENSE 	    
   - CONTACT.


-----------------------------------------------------------------
VB-CABLE (Audio Device driver)
-----------------------------------------------------------------

Programmed by V.Burel / JS-Loezic

Copyrights V.Burel�2010-2013 All rights reserved.

VB-CABLE is an Audio Driver working as virtual audio cable.
All signals sent to the device output is going on the device input.

To support our effort and development team, it is possible to make 
donation on www.VB-CABLE.com web site. Thanks by advance for your 
participation.


-----------------------------------------------------------------
INSTALLATION
-----------------------------------------------------------------

Just UNZIP the package in a folder somewhere on your hard-disk and 
launch the Setup program from there (! IN ADMINISTRATOR MODE !).

- VBCABLE_Setup.exe will install driver on 32 bit O/S
(will do nothing on 64 bit O/S)

- VBCABLE_Setup_x64.exe will install driver on 64 bit O/S
(will not run on 32bits O/S)

During installation, the Setup Application can be shown as 
"not responding" for few seconds. It is not a problem, 
just wait the end of the installation (a dialog-box will say you
when it is finished). 

It is recommanded to reboot after installation.

-----------------------------------------------------------------
LICENSE
-----------------------------------------------------------------

LICENSE AGREEMENT FOR END-USER

IMPORTANT - READ CAREFULLY BEFORE INSTALLING
FILES. BY INSTALLING THIS SOFTWARE, YOU AGREE
TO BE BOUND BY THE TERMS OF THE FOLLOWING 
AGREEMENT. IF YOU DO NOT AGREE TO THE TERMS 
OF THIS AGREEMENT, YOU MUST QUIT THIS SETUP 
PROGRAM.


LICENCE AGREEMENT

Vincent Burel (the author) give you (an individual
or a single entity) permission to use this software.
All files are protected by copyright and are 
property of Vincent Burel (The Author) according to
intellectual property laws and treaties. 
Software, files and documents are not public 
domain, and are protected by the copyright laws
of France.  

LIMITATIONS 

As the VB-CABLE is a donationware, it is also allowed
to copy and diffuse the VB-CABLE package AS IS without
any modification. It is not allowed to integrate the 
VB-CABLE package in another software installation 
procedure without Author agreement.

In case of distribution/diffusion you might mention:
1- The origin of VB-CABLE : www.vb-cable.com.
2- VB-CABLE is a donationware, all participations are welcome.    

DISCLAIMER: 

THE SOFTWARE AND DOCUMENTATIONS, TECHNICAL
OR NOT ARE PROVIDED AS-IS, WITHOUT WARRANTY
OF ANY KIND. VINCENT BUREL (THE AUTHOR)
DISCLAIMS ALL WARRANTIES RELATING TO THE
SOFTWARE, WHETHER EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO ANY IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE, AND ALL SUCH 
WARRANTIES ARE EXPRESSLY AND SPECIFICALLY
DISCLAIMED.

THE AUTHOR SHALL NOT BE LIABLE FOR ANY 
INDIRECT, CONSEQUENTIAL OR INCIDENTAL
DAMAGES ARISING OUT OF THE USE OR INABILITY
TO USE THE SOFTWARE EVEN IF THE AUTHOR HAS
BEEN ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES OR CLAIMS. THE USER OF THE SOFTWARE
BEARS ALL RISK AS TO THE QUALITY AND
PERFORMANCE OF THE SOFTWARE.


-----------------------------------------------------------------
CONTACT
-----------------------------------------------------------------

e-MAIL : vincent.burel@vb-audio.com

WEB : http://www.vb-audio.com
WEB : http://www.vb-cable.com